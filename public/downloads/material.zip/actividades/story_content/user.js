function ExecuteScript(strId)
{
  switch (strId)
  {
      case "61qpkXmVqlo":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

